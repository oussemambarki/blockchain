* The app is tested using Android Emulator(AVD Manager).

* The virtual device being used is Google Pixel 3A.

  > NOTE : The virtual device created or any device used must have a back camera and Google Play Store installed for proper functioning of the app. Google Play Services must be also up-to-date to avoid any errors.